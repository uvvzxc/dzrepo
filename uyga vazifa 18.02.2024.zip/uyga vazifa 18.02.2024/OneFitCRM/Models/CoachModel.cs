﻿namespace FitCRM.Models
{
    public class CoachModel
    {
    }
}
