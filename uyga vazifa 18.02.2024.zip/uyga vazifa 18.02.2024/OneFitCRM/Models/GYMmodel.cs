﻿namespace FitCRM.Models
{
    public class GYMmodel
    {
        public int id { get; set; }
        public string name { get; set; }
        public string location { get; set; }
        public string cost { get; set; }
        public string work_time {  get; set; }
        public int rate { get; set; }
        public string sport_type { get; set; }
    }
}
