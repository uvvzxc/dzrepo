﻿namespace FitCRM.Models
{
    public class MemberModel
    {
    }
}
