﻿namespace FitCRM.DTOs
{
    public class GYMmodelDTO
    {
        public string Name { get; set; }
        public string Location { get; set; }
        public string Cost { get; set; }
        public string Work_time { get; set; }
        public int Rate { get; set; }
        public string Sport_type { get; set; }
    }
}
