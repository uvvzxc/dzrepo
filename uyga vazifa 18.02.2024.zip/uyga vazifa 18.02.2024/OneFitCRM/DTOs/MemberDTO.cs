﻿namespace FitCRM.DTOs
{
    public class MemberDTO
    {
    }
}
