﻿namespace FitCRM.DTOs
{
    public class CoachDTO
    {
    }
}
